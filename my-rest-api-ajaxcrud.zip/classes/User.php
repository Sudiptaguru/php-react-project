<?php
class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $name;
    public $email;
    public $password;

    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function read($from_record_num, $records_per_page, $search_name = "", $search_email = "") {
        $query = "SELECT id, name, email FROM " . $this->table_name . " WHERE 1=1";
        
        if (!empty($search_name)) {
            $query .= " AND name LIKE :search_name";
        }
        if (!empty($search_email)) {
            $query .= " AND email LIKE :search_email";
        }

        $query .= " ORDER BY id ASC LIMIT :from_record_num, :records_per_page";
        
        $stmt = $this->conn->prepare($query);

        if (!empty($search_name)) {
            $search_name = "%{$search_name}%";
            $stmt->bindParam(':search_name', $search_name);
        }
        if (!empty($search_email)) {
            $search_email = "%{$search_email}%";
            $stmt->bindParam(':search_email', $search_email);
        }

        $stmt->bindParam(':from_record_num', $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(':records_per_page', $records_per_page, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt;
    }

    public function create() {
        if ($this->emailExists()) {
            return "Email already exists"; // Return specific error message
        }
        $query = "INSERT INTO " . $this->table_name . " SET name=:name, email=:email, password=:password";
        $stmt = $this->conn->prepare($query);
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function update() {
        if ($this->emailExists(true)) {
            return "Email already exists"; // Return specific error message
        }
        $query = "UPDATE " . $this->table_name . " SET name=:name, email=:email, password=:password WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password', $this->password);
        $stmt->bindParam(':id', $this->id);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }
    public function count($search_name = "", $search_email = "") {
        $query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . " WHERE 1=1";
        
        if (!empty($search_name)) {
            $query .= " AND name LIKE :search_name";
        }
        if (!empty($search_email)) {
            $query .= " AND email LIKE :search_email";
        }

        $stmt = $this->conn->prepare($query);

        if (!empty($search_name)) {
            $search_name = "%{$search_name}%";
            $stmt->bindParam(':search_name', $search_name);
        }
        if (!empty($search_email)) {
            $search_email = "%{$search_email}%";
            $stmt->bindParam(':search_email', $search_email);
        }

        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_rows'];
    }
    public function login() {
        $query = "SELECT id, name, password FROM " . $this->table_name . " WHERE email = :email LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($this->password, $row['password'])) {
                return array("id" => $row['id'], "name" => $row['name']);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private function emailExists($isUpdate = false) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE email = :email";
        if ($isUpdate) {
            $query .= " AND id != :id";
        }
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $this->email);
        if ($isUpdate) {
            $stmt->bindParam(":id", $this->id);
        }
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
}
?>
