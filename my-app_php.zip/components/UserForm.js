// src/components/UserForm.js
import React, { useState } from 'react';

const UserForm = ({ onSave }) => {
    const [formData, setFormData] = useState({ name: '', email: '', password: '', id: '' });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(formData);
        setFormData({ name: '', email: '', password: '', id: '' });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="hidden" name="id" value={formData.id} />
            <div>
                <label htmlFor="name">Name:</label>
                <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div>
                <label htmlFor="email">Email:</label>
                <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
            </div>
            <div>
                <label htmlFor="password">Password:</label>
                <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} required />
            </div>
            <button type="submit">Save</button>
        </form>
    );
};

export default UserForm;
