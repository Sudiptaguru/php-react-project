import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const checkLogin = async () => {
      try {
        const response = await fetch('http://localhost/my-rest-api-ajaxcrud/api/index.php?action=check_login', {
          method: 'GET',
          credentials: 'include', // Ensure cookies are sent with the request
        });

        if (!response.ok) {
          throw new Error('Not logged in');
        }

        const data = await response.json();

        if (data.user) {
          setUser(data.user);
        } else {
          navigate('/login'); // Redirect to login if not logged in
        }
      } catch {
        navigate('/login'); // Redirect to login on error
      }
    };

    checkLogin();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await fetch('http://localhost/my-rest-api-ajaxcrud/api/index.php?action=logout', {
        method: 'POST',
        credentials: 'include', // Ensure cookies are sent with the request
      });
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '50px auto' }}>
      <h2>Dashboard</h2>
      {user ? (
        <div id="userInfo">
          <p>Welcome, {user.name}!</p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default Dashboard;
