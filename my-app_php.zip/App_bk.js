import React, { useState, useEffect } from 'react';

const App = () => {
  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(5);
  const [totalPages, setTotalPages] = useState(1);
  const [formState, setFormState] = useState({ id: '', name: '', email: '', password: '' });
  const [searchParams, setSearchParams] = useState({ searchName: '', searchEmail: '' });

  useEffect(() => {
    fetchUsers();
  }, [currentPage, searchParams]);

  const fetchUsers = () => {
    const { searchName, searchEmail } = searchParams;
    fetch(`http://localhost/my-rest-api-ajaxcrud/api/index.php?page=${currentPage}&records_per_page=${recordsPerPage}&name=${searchName}&email=${searchEmail}`)
      .then(response => response.json())
      .then(data => {
        setUsers(data.records || []);
        const totalRows = data.total_rows || 0;
        setTotalPages(Math.ceil(totalRows / recordsPerPage));
      })
      .catch(error => console.error('Error fetching users:', error));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleSearchChange = (e) => {
    const { name, value } = e.target;
    setSearchParams({ ...searchParams, [name]: value });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const { id, name, email, password } = formState;
    const method = id ? 'PUT' : 'POST';
    const url = 'http://localhost/my-rest-api-ajaxcrud/api/index.php';

    fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, name, email, password })
    })
      .then(response => response.json())
      .then(data => {
        alert(data.message);
        setFormState({ id: '', name: '', email: '', password: '' });
        fetchUsers();
      })
      .catch(error => console.error('Error saving user:', error));
  };

  const handleEditUser = (user) => {
    setFormState(user);
  };

  const handleDeleteUser = (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      fetch('http://localhost/my-rest-api-ajaxcrud/api/index.php', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      })
        .then(response => response.json())
        .then(data => {
          alert(data.message);
          setCurrentPage(1);
          fetchUsers();
        })
        .catch(error => console.error('Error deleting user:', error));
    }
  };

  const handlePaginationClick = (newPage) => {
    setCurrentPage(newPage);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '50px auto' }}>
      <h1>PHP REST API CRUD with AJAX</h1>
      <form id="searchForm" onSubmit={(e) => e.preventDefault()}>
        <div>
          <label htmlFor="searchName">Search Name:</label>
          <input
            type="text"
            id="searchName"
            name="searchName"
            value={searchParams.searchName}
            onChange={handleSearchChange}
          />
        </div>
        <div>
          <label htmlFor="searchEmail">Search Email:</label>
          <input
            type="text"
            id="searchEmail"
            name="searchEmail"
            value={searchParams.searchEmail}
            onChange={handleSearchChange}
          />
        </div>
        {/* <button type="button" onClick={fetchUsers}>Search</button> */}
      </form>
      <br /><br />
      <form id="userForm" onSubmit={handleFormSubmit}>
        <input type="hidden" id="userId" name="id" value={formState.id} />
        <div>
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formState.name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formState.email}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formState.password}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type="submit">{formState.id ? 'Update' : 'Save'}</button>
      </form>
      <h2>User List</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>ID</th>
            <th style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>Name</th>
            <th style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>Email</th>
            <th style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.length > 0 ? (
            users.map((user) => (
              <tr key={user.id}>
                <td style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>{user.id}</td>
                <td style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>{user.name}</td>
                <td style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>{user.email}</td>
                <td style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>
                  <button onClick={() => handleEditUser(user)}>Edit</button>
                  <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" style={{ border: '1px solid black', padding: '10px', textAlign: 'left' }}>No users found</td>
            </tr>
          )}
        </tbody>
      </table>
      <div className="pagination" id="paginationControls" style={{ margin: '10px 0' }}>
        <a href="#!" onClick={() => handlePaginationClick(1)} style={{ margin: '0 5px', textDecoration: 'none' }}>First</a>
        <a href="#!" onClick={() => handlePaginationClick(currentPage > 1 ? currentPage - 1 : 1)} style={{ margin: '0 5px', textDecoration: 'none' }}>Previous</a>
        <a href="#!" onClick={() => handlePaginationClick(currentPage < totalPages ? currentPage + 1 : totalPages)} style={{ margin: '0 5px', textDecoration: 'none' }}>Next</a>
        <a href="#!" onClick={() => handlePaginationClick(totalPages)} style={{ margin: '0 5px', textDecoration: 'none' }}>Last</a>
      </div>
    </div>
  );
};

export default App;
